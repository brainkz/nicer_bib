A small utility for making BibTeX in your clipboard nicer by:
  - Capitalizing words in title
  - Removing unnecessary information for your LaTeX files, such as publisher or ISBN
  - Collapsing the first and middle names into initials
